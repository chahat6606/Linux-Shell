 clear
 gcc -o a main.c texts.c custerrors.c history.c
 ./a